//
//  ShowMessage.h
//  MySDK
//
//  Created by Pokkt on 05/04/17.
//  Copyright © 2017 Pokkt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShowMessage : NSObject
{
    
}

+(void)printMessage;
@end
