//
//  MySDK.h
//  MySDK
//
//  Created by Pokkt on 05/04/17.
//  Copyright © 2017 Pokkt. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MySDK.
FOUNDATION_EXPORT double MySDKVersionNumber;

//! Project version string for MySDK.
FOUNDATION_EXPORT const unsigned char MySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySDK/PublicHeader.h>

#import <MySDK/ShowMessage.h>


